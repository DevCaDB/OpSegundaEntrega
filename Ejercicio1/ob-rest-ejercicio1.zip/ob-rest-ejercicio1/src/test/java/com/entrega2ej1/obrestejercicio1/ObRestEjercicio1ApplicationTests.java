package com.entrega2ej1.obrestejercicio1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObRestEjercicio1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
