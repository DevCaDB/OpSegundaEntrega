package com.entrega2ej1.obrestejercicio1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObRestEjercicio1Application {

	public static void main(String[] args) {
		SpringApplication.run(ObRestEjercicio1Application.class, args);
	}

}
