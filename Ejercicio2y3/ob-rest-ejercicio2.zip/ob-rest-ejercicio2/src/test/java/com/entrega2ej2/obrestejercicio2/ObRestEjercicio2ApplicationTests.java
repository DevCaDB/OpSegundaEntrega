package com.entrega2ej2.obrestejercicio2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObRestEjercicio2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
