package com.entrega2ej2.obrestejercicio2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObRestEjercicio2Application {

	public static void main(String[] args) {
		SpringApplication.run(ObRestEjercicio2Application.class, args);
	}

}
